# Importing Required Libraries


```python
import pandas as pd 
import datetime  #to convert the data and time 
import numpy as np
import seaborn as sns
from sqlalchemy import create_engine,MetaData,Table,Column,Integer ,String
engine=create_engine("sqlite://",echo=True)

%matplotlib inline
import matplotlib.pyplot as plt
```

## loading the data 


```python
def get_data(week_nums):
    url = "http://web.mta.info/developers/data/nyct/turnstile/turnstile_{}.txt"
    dfs= []
    for week_num in week_nums:
        file_url = url.format(week_num)
        dfs.append(pd.read_csv(file_url))
    return pd.concat(dfs)

week_nums = [170107, 170114, 170128, 170204,  170211, 170218, 170225 ,
            170304, 170304, 170311, 170311, 170318, 170325, 170401, 170408, 170415, 170422, 170429]
turnstiles_df = get_data(week_nums)

#the chosen data covers first quarter of 2017. Data size is over 5 million
#C/A - Control Area name/Booth name. This is the internal identification of a booth at a given station.
#Unit - Remote unit ID of station.
#SCP - Subunit/Channel/position represents a specific address for a given device. STATION - Name assigned to the subway station by operations planning. This name is used in all references to stations,
#date = Represents the date (MM-DD-YY)
#time = Represents the time (hh:mm:ss) for a scheduled audit event
#datetime = date + time (MM-DD-YY hh:mm:ss)
#desc = Represent the "REGULAR" scheduled audit event (Normally occurs every 4 hours)
#entries = The comulative entry register value for a device
#exits = The cumulative exit register value for a device
#as well as in debit/credit purchase receipts, and customer’s bank activity statements.
```

#  Exploring the data  


```python
turnstiles_df.head()
#in this analysis we use data for the first quarter of 2017 
#the data includes 3537242 rows × 11 columns
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>LINENAME</th>
      <th>DIVISION</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>DESC</th>
      <th>ENTRIES</th>
      <th>EXITS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5991546</td>
      <td>2028378</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>07:00:00</td>
      <td>REGULAR</td>
      <td>5991565</td>
      <td>2028389</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>11:00:00</td>
      <td>REGULAR</td>
      <td>5991644</td>
      <td>2028441</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>15:00:00</td>
      <td>REGULAR</td>
      <td>5991971</td>
      <td>2028502</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>19:00:00</td>
      <td>REGULAR</td>
      <td>5992418</td>
      <td>2028543</td>
    </tr>
  </tbody>
</table>
</div>




```python
# we found station 59 is the msot crowded particularly at 19:00 at linename NQR456W 
turnstiles_df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>LINENAME</th>
      <th>DIVISION</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>DESC</th>
      <th>ENTRIES</th>
      <th>EXITS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>198255</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>05:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
    <tr>
      <th>198256</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>09:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
    <tr>
      <th>198257</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>13:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
    <tr>
      <th>198258</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>17:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
    <tr>
      <th>198259</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>21:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
  </tbody>
</table>
</div>




```python
type(turnstiles_df)
```




    pandas.core.frame.DataFrame




```python
type(turnstiles_df['DESC'])
```




    pandas.core.series.Series




```python
type(turnstiles_df['ENTRIES'])
```




    pandas.core.series.Series




```python
# Get rid of the duplicate entry
turnstiles_df.sort_values(["C/A", "UNIT", "SCP", "STATION", "DATE"], 
                          inplace=True, ascending=False)
turnstiles_df.drop_duplicates(subset=["C/A", "UNIT", "SCP", "STATION", "DATE"], inplace=True)
turnstiles_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>LINENAME</th>
      <th>DIVISION</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>DESC</th>
      <th>ENTRIES</th>
      <th>EXITS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>194731</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>12/31/2016</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>283</td>
    </tr>
    <tr>
      <th>198254</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>01:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
    <tr>
      <th>198248</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/27/2017</td>
      <td>01:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
    <tr>
      <th>198242</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/26/2017</td>
      <td>01:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
    <tr>
      <th>198236</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/25/2017</td>
      <td>01:00:00</td>
      <td>REGULAR</td>
      <td>5554</td>
      <td>297</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>30</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/05/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5997901</td>
      <td>2030268</td>
    </tr>
    <tr>
      <th>24</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/04/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5996263</td>
      <td>2029669</td>
    </tr>
    <tr>
      <th>18</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/03/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5994505</td>
      <td>2029072</td>
    </tr>
    <tr>
      <th>12</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/02/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5993559</td>
      <td>2028754</td>
    </tr>
    <tr>
      <th>6</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/01/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5992718</td>
      <td>2028585</td>
    </tr>
  </tbody>
</table>
<p>522008 rows × 11 columns</p>
</div>



## exploring the data :


```python
#I am going to prove the hypothesis by analyzing and getting the evidence 
mask=(turnstiles_df.ENTRIES > 5554).head(10)
```


```python
mask 
```




    194731    False
    198254    False
    198248    False
    198242    False
    198236    False
    198230    False
    198224    False
    198218    False
    197355    False
    197349    False
    Name: ENTRIES, dtype: bool




```python

#change to timeSerises and make it in one col called [DATE_TIME]
turnstiles_df["DATE_TIME"] = pd.to_datetime(turnstiles_df.DATE+" "+turnstiles_df.TIME,
                                                  format="%m/%d/%Y %H:%M:%S")
```


```python
turnstiles_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 522008 entries, 194731 to 6
    Data columns (total 12 columns):
     #   Column                                                                Non-Null Count   Dtype         
    ---  ------                                                                --------------   -----         
     0   C/A                                                                   522008 non-null  object        
     1   UNIT                                                                  522008 non-null  object        
     2   SCP                                                                   522008 non-null  object        
     3   STATION                                                               522008 non-null  object        
     4   LINENAME                                                              522008 non-null  object        
     5   DIVISION                                                              522008 non-null  object        
     6   DATE                                                                  522008 non-null  object        
     7   TIME                                                                  522008 non-null  object        
     8   DESC                                                                  522008 non-null  object        
     9   ENTRIES                                                               522008 non-null  int64         
     10  EXITS                                                                 522008 non-null  int64         
     11  DATE_TIME                                                             522008 non-null  datetime64[ns]
    dtypes: datetime64[ns](1), int64(2), object(9)
    memory usage: 51.8+ MB
    


```python
turnstiles_df.STATION.value_counts()
```




    34 ST-PENN STA     10971
    FULTON ST          10745
    23 ST               7943
    GRD CNTRL-42 ST     6904
    CANAL ST            6490
                       ...  
    53 ST                320
    PATH WTC 2           312
    PENNSYLVANIA AV      252
    CLEVELAND ST         224
    SUTTER AV            222
    Name: STATION, Length: 376, dtype: int64




```python
turnstiles_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ENTRIES</th>
      <th>EXITS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5.220080e+05</td>
      <td>5.220080e+05</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>3.618867e+07</td>
      <td>2.885551e+07</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.968606e+08</td>
      <td>1.773107e+08</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>5.058820e+05</td>
      <td>2.451038e+05</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.622433e+06</td>
      <td>1.480404e+06</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.691756e+06</td>
      <td>4.721534e+06</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2.130669e+09</td>
      <td>2.087387e+09</td>
    </tr>
  </tbody>
</table>
</div>




```python
turnstiles_df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>LINENAME</th>
      <th>DIVISION</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>DESC</th>
      <th>ENTRIES</th>
      <th>EXITS</th>
      <th>DATE_TIME</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>30</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/05/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5997901</td>
      <td>2030268</td>
      <td>2017-01-05 03:00:00</td>
    </tr>
    <tr>
      <th>24</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/04/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5996263</td>
      <td>2029669</td>
      <td>2017-01-04 03:00:00</td>
    </tr>
    <tr>
      <th>18</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/03/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5994505</td>
      <td>2029072</td>
      <td>2017-01-03 03:00:00</td>
    </tr>
    <tr>
      <th>12</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/02/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5993559</td>
      <td>2028754</td>
      <td>2017-01-02 03:00:00</td>
    </tr>
    <tr>
      <th>6</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>01/01/2017</td>
      <td>03:00:00</td>
      <td>REGULAR</td>
      <td>5992718</td>
      <td>2028585</td>
      <td>2017-01-01 03:00:00</td>
    </tr>
  </tbody>
</table>
</div>




```python
#taking a glance in the columns 
turnstiles_df.columns
```




    Index(['C/A', 'UNIT', 'SCP', 'STATION', 'LINENAME', 'DIVISION', 'DATE', 'TIME',
           'DESC', 'ENTRIES',
           'EXITS                                                               ',
           'DATE_TIME'],
          dtype='object')




```python
#I noticed there is a space in exits , so I remove it by this method
turnstiles_df.rename(columns={'EXITS' 
:'EXITS'}, inplace=True)
```


```python
#or talking away from space 
turnstiles_df.columns = [column.strip() for column in turnstiles_df.columns]
turnstiles_df.columns
```




    Index(['C/A', 'UNIT', 'SCP', 'STATION', 'LINENAME', 'DIVISION', 'DATE', 'TIME',
           'DESC', 'ENTRIES', 'EXITS', 'DATE_TIME'],
          dtype='object')




```python

turnstiles_df.plot(kind='scatter',x='DATE',y='ENTRIES')
```




    <AxesSubplot:xlabel='DATE', ylabel='ENTRIES'>




    
![png](output_22_1.png)
    



```python
import seaborn as sns
sns.pairplot(turnstiles_df);new_x =np.arange(100)
new_y= np.random.randint(0,10,100)
plt.plot(new_x,new_y);
```


    
![png](output_23_0.png)
    



```python
new_x = np.random.randn(1000)
new_y = np.random.randn(1000)
plt.scatter(new_x,new_y);
```


    
![png](output_24_0.png)
    



```python
#explore teh null values 
turnstiles_df.isna()
```

# database manipulation  :


```python
##creating a table 
   
meta=MetaData()
tours =Table(
 'tours',meta,
    Column('id',Integer,primary_key=True),
    Column('name',String ),
    Column('description',String ),)
meta.create_all(engine)
```


```python
all_tables=engine.table_names()
all_tables 
```


```python
engine.execute('INSERT INTO "tours" (id,name,description) VALUES(102," PARK tour","moving within and around Central park the activties included ")')
engine.execute('INSERT INTO "tours" (id,name,description) VALUES(103,"Broadway shows","walking on broadway street ")')
engine.execute('INSERT INTO "tours"(id,name,description) VALUES(104,"famous universities tour","visiting the most famous universities")')
engine.execute('INSERT INTO "tours" (id,name,description) VALUES(105,"Times square tour","hang out in the times sqare ")')
engine.execute('INSERT INTO "tours"(id,name,description) VALUES(106,"LIBER status ","talking the fair ")')
```


```python
meta=MetaData()
tourist =Table(
'tourist',meta,
    Column('id',Integer,primary_key=True),
    Column('name',String),)
meta.create_all(engine)
```


```python
all_tables=engine.table_names()
all_tables
```


```python
engine.execute('INSERT INTO tourist (id,name)VALUES(101,"rola")')                               
engine.execute('INSERT INTO tourist (id,name)VALUES(102," Ronald")')
engine.execute('INSERT INTO tourist (id,name)VALUES(103,"John ")')
engine.execute('INSERT INTO tourist (id,name)VALUES(104," Archy ")')

```


```python
students_data=pd.read_sql('SELECT *FROM tours',engine)
students_data
```

# the end of sqlalchemy 


```python
#we will study the situation for two stations  
mask = ((turnstiles_df["C/A"] == "A002") &
        (turnstiles_df["UNIT"] == "R051") & 
        (turnstiles_df["SCP"] == "02-00-00") & 
        (turnstiles_df["STATION"] == "59 ST"))

turnstiles_df[mask].head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>LINENAME</th>
      <th>DIVISION</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>DESC</th>
      <th>ENTRIES</th>
      <th>EXITS</th>
      <th>DATE_TIME</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>37</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>04/28/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>6156153</td>
      <td>2084732</td>
      <td>2017-04-28</td>
    </tr>
    <tr>
      <th>31</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>04/27/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>6154537</td>
      <td>2084226</td>
      <td>2017-04-27</td>
    </tr>
    <tr>
      <th>25</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>04/26/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>6153037</td>
      <td>2083698</td>
      <td>2017-04-26</td>
    </tr>
    <tr>
      <th>19</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>04/25/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>6151473</td>
      <td>2083124</td>
      <td>2017-04-25</td>
    </tr>
    <tr>
      <th>12</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>04/24/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>6149971</td>
      <td>2082630</td>
      <td>2017-04-24</td>
    </tr>
  </tbody>
</table>
</div>




```python

mask = ((turnstiles_df["C/A"] == "R626") & 
(turnstiles_df["UNIT"] == "R062") & 
(turnstiles_df["SCP"] == "00-00-00") & 
(turnstiles_df["STATION"] == "CROWN HTS-UTICA"))

turnstiles_df[mask].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>LINENAME</th>
      <th>DIVISION</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>DESC</th>
      <th>ENTRIES</th>
      <th>EXITS</th>
      <th>DATE_TIME</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>192012</th>
      <td>R626</td>
      <td>R062</td>
      <td>00-00-00</td>
      <td>CROWN HTS-UTICA</td>
      <td>34</td>
      <td>IRT</td>
      <td>04/28/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>12793993</td>
      <td>2846738</td>
      <td>2017-04-28</td>
    </tr>
    <tr>
      <th>192006</th>
      <td>R626</td>
      <td>R062</td>
      <td>00-00-00</td>
      <td>CROWN HTS-UTICA</td>
      <td>34</td>
      <td>IRT</td>
      <td>04/27/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>12790034</td>
      <td>2845992</td>
      <td>2017-04-27</td>
    </tr>
    <tr>
      <th>192000</th>
      <td>R626</td>
      <td>R062</td>
      <td>00-00-00</td>
      <td>CROWN HTS-UTICA</td>
      <td>34</td>
      <td>IRT</td>
      <td>04/26/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>12786405</td>
      <td>2845230</td>
      <td>2017-04-26</td>
    </tr>
    <tr>
      <th>191994</th>
      <td>R626</td>
      <td>R062</td>
      <td>00-00-00</td>
      <td>CROWN HTS-UTICA</td>
      <td>34</td>
      <td>IRT</td>
      <td>04/25/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>12782954</td>
      <td>2844543</td>
      <td>2017-04-25</td>
    </tr>
    <tr>
      <th>191988</th>
      <td>R626</td>
      <td>R062</td>
      <td>00-00-00</td>
      <td>CROWN HTS-UTICA</td>
      <td>34</td>
      <td>IRT</td>
      <td>04/24/2017</td>
      <td>00:00:00</td>
      <td>REGULAR</td>
      <td>12779096</td>
      <td>2843772</td>
      <td>2017-04-24</td>
    </tr>
  </tbody>
</table>
</div>




```python
#i notice a strange situation where the cumulative entries number dosen't increas gradualy 
```


```python
turnstiles_daily = (turnstiles_df
                        .groupby(["C/A", "UNIT", "SCP", "STATION", "DATE"],as_index=False)
                        .ENTRIES.first())
```


```python
turnstiles_daily
#the problem still hapeen ,What's the deal with counter being in reverse
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/01/2017</td>
      <td>5992718</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/02/2017</td>
      <td>5993559</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/03/2017</td>
      <td>5994505</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/04/2017</td>
      <td>5996263</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/05/2017</td>
      <td>5997901</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>522003</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/25/2017</td>
      <td>5554</td>
    </tr>
    <tr>
      <th>522004</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/26/2017</td>
      <td>5554</td>
    </tr>
    <tr>
      <th>522005</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/27/2017</td>
      <td>5554</td>
    </tr>
    <tr>
      <th>522006</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/28/2017</td>
      <td>5554</td>
    </tr>
    <tr>
      <th>522007</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>12/31/2016</td>
      <td>5554</td>
    </tr>
  </tbody>
</table>
<p>522008 rows × 6 columns</p>
</div>




```python
# Sanity Check to verify that "C/A", "UNIT", "SCP", "STATION", "DATE_TIME" is unique
(turnstiles_df
 .groupby(["C/A", "UNIT", "SCP", "STATION", "DATE_TIME"])
 .ENTRIES.count()
 .reset_index()
 .sort_values("ENTRIES", ascending=False)).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE_TIME</th>
      <th>ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>2016-12-31 03:00:00</td>
      <td>1</td>
    </tr>
    <tr>
      <th>348001</th>
      <td>R145</td>
      <td>R032</td>
      <td>00-00-02</td>
      <td>TIMES SQ-42 ST</td>
      <td>2017-04-02 00:00:00</td>
      <td>1</td>
    </tr>
    <tr>
      <th>348014</th>
      <td>R145</td>
      <td>R032</td>
      <td>00-00-02</td>
      <td>TIMES SQ-42 ST</td>
      <td>2017-04-15 00:00:00</td>
      <td>1</td>
    </tr>
    <tr>
      <th>348013</th>
      <td>R145</td>
      <td>R032</td>
      <td>00-00-02</td>
      <td>TIMES SQ-42 ST</td>
      <td>2017-04-14 00:00:00</td>
      <td>1</td>
    </tr>
    <tr>
      <th>348012</th>
      <td>R145</td>
      <td>R032</td>
      <td>00-00-02</td>
      <td>TIMES SQ-42 ST</td>
      <td>2017-04-13 00:00:00</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
turnstiles_daily[["PREV_DATE", "PREV_ENTRIES"]] = (turnstiles_daily
                                                       .groupby(["C/A", "UNIT", "SCP", "STATION"])["DATE", "ENTRIES"]
                                                       .apply(lambda grp: grp.shift(1)))
```

    <ipython-input-47-3a945374269e>:1: FutureWarning: Indexing with multiple keys (implicitly converted to a tuple of keys) will be deprecated, use a list instead.
      turnstiles_daily[["PREV_DATE", "PREV_ENTRIES"]] = (turnstiles_daily
    


```python
turnstiles_daily.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
      <th>PREV_DATE</th>
      <th>PREV_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/01/2017</td>
      <td>5992718</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/02/2017</td>
      <td>5993559</td>
      <td>01/01/2017</td>
      <td>5992718.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/03/2017</td>
      <td>5994505</td>
      <td>01/02/2017</td>
      <td>5993559.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/04/2017</td>
      <td>5996263</td>
      <td>01/03/2017</td>
      <td>5994505.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/05/2017</td>
      <td>5997901</td>
      <td>01/04/2017</td>
      <td>5996263.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
turnstiles_daily.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
      <th>PREV_DATE</th>
      <th>PREV_ENTRIES</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>522003</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/25/2017</td>
      <td>5554</td>
      <td>04/24/2017</td>
      <td>5554.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>522004</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/26/2017</td>
      <td>5554</td>
      <td>04/25/2017</td>
      <td>5554.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>522005</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/27/2017</td>
      <td>5554</td>
      <td>04/26/2017</td>
      <td>5554.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>522006</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/28/2017</td>
      <td>5554</td>
      <td>04/27/2017</td>
      <td>5554.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>522007</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>12/31/2016</td>
      <td>5554</td>
      <td>04/28/2017</td>
      <td>5554.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Drop the rows for the earliest date in the df
turnstiles_daily.dropna(subset=["PREV_DATE"], axis=0, inplace=True)

```


```python
turnstiles_daily
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
      <th>PREV_DATE</th>
      <th>PREV_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/02/2017</td>
      <td>5993559</td>
      <td>01/01/2017</td>
      <td>5992718.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/03/2017</td>
      <td>5994505</td>
      <td>01/02/2017</td>
      <td>5993559.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/04/2017</td>
      <td>5996263</td>
      <td>01/03/2017</td>
      <td>5994505.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/05/2017</td>
      <td>5997901</td>
      <td>01/04/2017</td>
      <td>5996263.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/06/2017</td>
      <td>5999649</td>
      <td>01/05/2017</td>
      <td>5997901.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>522003</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/25/2017</td>
      <td>5554</td>
      <td>04/24/2017</td>
      <td>5554.0</td>
    </tr>
    <tr>
      <th>522004</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/26/2017</td>
      <td>5554</td>
      <td>04/25/2017</td>
      <td>5554.0</td>
    </tr>
    <tr>
      <th>522005</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/27/2017</td>
      <td>5554</td>
      <td>04/26/2017</td>
      <td>5554.0</td>
    </tr>
    <tr>
      <th>522006</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/28/2017</td>
      <td>5554</td>
      <td>04/27/2017</td>
      <td>5554.0</td>
    </tr>
    <tr>
      <th>522007</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>12/31/2016</td>
      <td>5554</td>
      <td>04/28/2017</td>
      <td>5554.0</td>
    </tr>
  </tbody>
</table>
<p>517283 rows × 8 columns</p>
</div>




```python
(turnstiles_daily[turnstiles_daily["ENTRIES"] < turnstiles_daily["PREV_ENTRIES"]]
    .groupby(["C/A", "UNIT", "SCP", "STATION"])
    .size())
##creating a table 
   

```




    C/A    UNIT  SCP       STATION      
    A002   R051  02-00-00  59 ST            1
                 02-00-01  59 ST            1
                 02-03-00  59 ST            1
                 02-03-01  59 ST            1
                 02-03-02  59 ST            1
                                           ..
    TRAM2  R469  00-00-00  RIT-ROOSEVELT    1
                 00-00-01  RIT-ROOSEVELT    1
                 00-03-00  RIT-ROOSEVELT    1
                 00-03-01  RIT-ROOSEVELT    1
                 00-05-00  RIT-ROOSEVELT    1
    Length: 4429, dtype: int64




```python
def get_daily_counts(row, max_counter):
    counter = row["ENTRIES"] - row["PREV_ENTRIES"]
    if counter < 0:
        counter = -counter
    if counter > max_counter:
        print(row["ENTRIES"], row["PREV_ENTRIES"])
        return 0
    return counter

# If counter is > 1Million, then the counter might have been reset.  
# Just set it to zero as different counters have different cycle limits
_ = turnstiles_daily.apply(get_daily_counts, axis=1, max_counter=1000000)
```

    1241453652 11978209.0
    11887428 1241119235.0
    1866 10201425.0
    10123458 74917.0
    67109168 135642.0
    129283 67246715.0
    100664101 3701460.0
    1112 100726770.0
    3698361 4776.0
    67108864 832.0
    262912 67108865.0
    100663315 262912.0
    832 100663332.0
    1868 1431723.0
    1424812 105316.0
    2802 6926320.0
    6830018 14538.0
    419299441 285113531.0
    285016031 419273605.0
    837 284994121.0
    284945900 58186.0
    539 8186848.0
    8186451 106043.0
    2031088564 10518173.0
    10325789 2031070632.0
    117484783 471260.0
    393537 117492963.0
    458752 4773394.0
    4696514 476635.0
    1946191222 7661697.0
    7606246 1946199336.0
    838882038 3322932.0
    3211184 838923138.0
    1103 7011426.0
    6842060 116789.0
    1937 2945098.0
    2901769 29410.0
    150994944 66.0
    63 150994975.0
    68 150994944.0
    150994944 68.0
    2083 3316604.0
    3190077 85908.0
    262190 6576459.0
    6484352 269685.0
    2438 9417254.0
    9304926 12674.0
    67109031 546899.0
    117440534 67109932.0
    202 117440534.0
    2014 4117161.0
    4102208 21215.0
    2130669260 8476560.0
    8445394 2130512276.0
    2833 1111672.0
    117440721 838749.0
    812929 117467674.0
    3878 2741192.0
    2736570 38866.0
    1157637815 4565147.0
    4538165 1157757276.0
    3249 1713154.0
    1609792 86721.0
    3257 10051710.0
    9989424 53492.0
    533 12166448.0
    12012635 78466.0
    824640994 7076792.0
    7029615 824773177.0
    117440512 0.0
    0 117440512.0
    134219089 3189.0
    957 134239803.0
    100663716 8954.0
    361551 100827270.0
    140 137111492.0
    137111199 2098.0
    76 1207687.0
    1139974 31516.0
    90 3440761.0
    3387140 24656.0
    596 2688348.0
    2681346 47616.0
    4532 8036361.0
    7778322 397464.0
    828 3834191.0
    3704004 86668.0
    1044 1402333.0
    1398567 2395.0
    659 665415304.0
    665289851 54824.0
    297 2296546.0
    2288069 18790.0
    2507 14181726.0
    13950073 227988.0
    3370113 103217105.0
    67109884 3369937.0
    67108947 103214872.0
    103219486 67108947.0
    67109547 3368330.0
    127 67109547.0
    3322852 55822.0
    145 3879912.0
    3813141 16118.0
    192 2146872.0
    2113118 33038.0
    2246 1028654.0
    1006237 4364.0
    84110511 3409570.0
    3371646 84129022.0
    3410482 84109915.0
    84072589 3441455.0
    480 3292006.0
    3274396 24881.0
    2326 19677845.0
    19581214 184283.0
    117440512 9966566.0
    9919805 117534042.0
    117440514 2582.0
    2565 117440514.0
    134217880 168419996.0
    168400396 134238538.0
    1929349962 9255304.0
    9094562 1929317814.0
    3437117 67329076.0
    135 3535278.0
    3530986 28885.0
    6220 1927705.0
    1916292 103916.0
    16779087 70693.0
    2224 16799815.0
    882 1941584.0
    1869416 199241.0
    1063 1448912.0
    1385599 157871.0
    360 2450330.0
    2388685 21509.0
    2423 2288706.0
    2269392 156274.0
    873 1757455.0
    1728344 95899.0
    11214 1154256781.0
    1154291966 96385.0
    178 1938072.0
    1936128 22816.0
    954 3410129.0
    3267972 30633.0
    853 1855093.0
    1683732 150063.0
    67108920 442042.0
    208901 67169083.0
    526174 18553246.0
    18457401 682381.0
    1633 1558447.0
    1342969 1633.0
    3630 34755189.0
    34719376 167096.0
    1074 16660967.0
    16422939 8439.0
    2476 2567690.0
    2538464 68450.0
    44 13531479.0
    13274552 59104.0
    1882 9700114.0
    9538625 50295.0
    632 537737953.0
    537648675 28696.0
    50331734 35123.0
    119 50337328.0
    922761058 3446.0
    4 922761058.0
    2953 4716316.0
    4634786 103641.0
    1332 1158157.0
    3744 9494470.0
    9454968 167114.0
    1737 5962068.0
    5896299 47714.0
    117440514 76.0
    262407 117440571.0
    100710824 344567.0
    254025 100712979.0
    634 4208028.0
    4180123 95142.0
    13404064 1923022.0
    1923044 13404511.0
    0 1923044.0
    1861961 30910.0
    17881992 3237616.0
    3237649 17882744.0
    2 3237649.0
    3091863 55820.0
    1792 28533742.0
    4499664 1792.0
    19631 32611926.0
    1923044 13402384.0
    13186694 2140868.0
    3237649 17879878.0
    17612884 3478222.0
    1792 28529236.0
    28167813 218914.0
    13404729 1765134.0
    1576347 13473312.0
    17883120 13945905.0
    13663418 17954683.0
    28534459 8313479.0
    8030471 28601944.0
    1969278 3481634.0
    3225986 2039281.0
    32611926 10322474.0
    10034133 32637272.0
    797 520746383.0
    520728883 77092.0
    303 8245866.0
    8126871 121660.0
    2 134217823.0
    134217787 95.0
    16187470 117440512.0
    0 16187470.0
    117440512 0.0
    2752980 101427108.0
    692 2780905.0
    101380002 36094.0
    8143 1937570.0
    1916634 89135.0
    0 3926691.0
    3870486 58518.0
    67108867 887.0
    859 67108867.0
    134218754 573098.0
    516432 134249766.0
    12069786 42149.0
    37276 12185692.0
    202 2564991.0
    2501799 70233.0
    335580007 1356852.0
    1231641 335602612.0
    201327245 67247793.0
    67228924 201382124.0
    332 3826931.0
    3791032 66609.0
    2480 6630213.0
    6557362 35162.0
    3610141 538709.0
    540628 3610141.0
    


```python
def get_daily_counts(row, max_counter):
    counter = row["ENTRIES"] - row["PREV_ENTRIES"]
    if counter < 0:
        # Maybe counter is reversed?
        counter = -counter
    if counter > max_counter:
        # Maybe counter was reset to 0? 
        print(row["ENTRIES"], row["PREV_ENTRIES"])
        counter = min(row["ENTRIES"], row["PREV_ENTRIES"])
    if counter > max_counter:
        # Check it again to make sure we're not still giving a counter that's too big
        return 0
    return counter

# If counter is > 1Million, then the counter might have been reset.  
# Just set it to zero as different counters have different cycle limits
# It'd probably be a good idea to use a number even significantly smaller than 1 million as the limit!
turnstiles_daily["DAILY_ENTRIES"] = turnstiles_daily.apply(get_daily_counts, axis=1, max_counter=1000000)
```

    1241453459 11978209.0
    11885857 1241122778.0
    2173 10201560.0
    10122631 73317.0
    67108981 135340.0
    128516 67245263.0
    100664284 3701657.0
    1429 100727135.0
    3697537 3181.0
    67108864 832.0
    100663315 67108865.0
    832 100663332.0
    1745 1431254.0
    1424402 104140.0
    2843 6926368.0
    6829565 13554.0
    419299435 285113520.0
    285016014 419273590.0
    153 284994405.0
    284946825 56085.0
    30 8186672.0
    8185618 106039.0
    2031090592 10515250.0
    10325789 2031073365.0
    117484830 471282.0
    393089 117492085.0
    458752 4773394.0
    4695802 475802.0
    1946191240 7661697.0
    7605883 1946198651.0
    838882067 3322993.0
    3211172 838922600.0
    1039 7009645.0
    6840587 113974.0
    2007 2945113.0
    2901408 28743.0
    150994944 66.0
    63 150994975.0
    68 150994944.0
    150994944 68.0
    1053 3315326.0
    3188921 84379.0
    262186 6576434.0
    6484072 269592.0
    2580 9417390.0
    9304041 11553.0
    67109041 546902.0
    117440541 67109932.0
    208 117440541.0
    2039 4117180.0
    4102042 20964.0
    2130669175 8476560.0
    8444666 2130514147.0
    1825 1111672.0
    117440740 838749.0
    812774 117467272.0
    3627 2740774.0
    2736293 38491.0
    1157637840 4565176.0
    4537910 1157755679.0
    3196 1712913.0
    1609247 84462.0
    1902 10051252.0
    9989108 52213.0
    533 12165851.0
    12011263 76163.0
    824640036 7075414.0
    7028093 824771111.0
    117440512 0.0
    0 117440512.0
    134219029 3169.0
    905 134239578.0
    100663785 9050.0
    360349 100824877.0
    128 137111469.0
    137111182 2077.0
    121 1207712.0
    1139393 30690.0
    112 3440785.0
    3386813 23882.0
    645 2688426.0
    2681346 46997.0
    1792 8034135.0
    7776112 394338.0
    1051 3834191.0
    3702654 84381.0
    1048 1402337.0
    1398544 2363.0
    720 665415359.0
    665288905 52483.0
    301 2296560.0
    2287935 18556.0
    3016 14182193.0
    13947667 223599.0
    3370114 103217121.0
    67109668 3369285.0
    67108948 103214884.0
    103219499 67108948.0
    67109547 3367570.0
    88 67109547.0
    3322373 54373.0
    177 3879936.0
    3812699 15189.0
    218 2146903.0
    2112784 32415.0
    1802 1028634.0
    1006044 4364.0
    84110542 3409584.0
    3371629 84128528.0
    3410552 84109918.0
    84072485 3440551.0
    480 3292006.0
    3274393 24400.0
    2332 19677849.0
    19580353 180703.0
    117440512 9966275.0
    9918887 117533023.0
    117440513 2582.0
    2565 117440514.0
    134217888 168420006.0
    168400248 134238068.0
    1929349661 9255532.0
    9093088 1929319623.0
    3436467 67326259.0
    91 3534893.0
    3530923 28549.0
    5830 1926461.0
    1915919 102641.0
    16779156 70714.0
    2252 16799876.0
    966 1941591.0
    1867842 196212.0
    1140 1449005.0
    1384300 155494.0
    443 2450544.0
    2387811 19954.0
    1485 2287075.0
    2268808 154703.0
    0 1757432.0
    1727801 94426.0
    11263 1154256750.0
    1154292615 95265.0
    43 1937956.0
    1936044 22555.0
    1096 3410129.0
    3267297 28655.0
    1014 1855093.0
    1682828 146977.0
    67108920 442960.0
    208898 67166938.0
    524352 18552246.0
    18456754 680388.0
    2185 34755039.0
    34718604 165359.0
    1205 16661132.0
    16421595 6169.0
    2572 2567873.0
    2537750 67327.0
    254 13531487.0
    13272719 56082.0
    11 9700058.0
    9537021 48220.0
    188 537737621.0
    537647794 27494.0
    50331736 35123.0
    142 50337354.0
    922761061 3451.0
    4 922761061.0
    3051 4716454.0
    4634205 101618.0
    1502 1158157.0
    2001 9493999.0
    9453791 165211.0
    1339 5962068.0
    5895175 45642.0
    117440514 77.0
    262407 117440570.0
    100710912 344667.0
    253670 100712048.0
    674 4208067.0
    4179843 94078.0
    13402911 1923017.0
    1923044 13404371.0
    0 1923044.0
    1860308 28961.0
    17880430 3237599.0
    3237649 17882503.0
    2 3237649.0
    3089724 52773.0
    1792 28533362.0
    4499664 1792.0
    19631 32611547.0
    1923044 13399967.0
    13184776 2134476.0
    3237649 17877102.0
    17610696 3471294.0
    1792 28525755.0
    28165610 212996.0
    13404768 1768290.0
    1574156 13470576.0
    17883188 13949957.0
    13660271 17952339.0
    28534605 8317969.0
    8026836 28601944.0
    1969557 3485630.0
    3222202 2039281.0
    32611926 10326952.0
    10029800 32637272.0
    851 520746632.0
    520728385 76163.0
    78 8245866.0
    8125425 118914.0
    2 134217823.0
    134217782 91.0
    0 117440512.0
    117440512 0.0
    2753001 101427118.0
    810 2781038.0
    101379731 34888.0
    7419 1935629.0
    1916045 87217.0
    0 3926728.0
    3869707 57259.0
    134217746 573098.0
    516020 134248590.0
    12069873 42219.0
    36579 12184468.0
    224 2564994.0
    2500934 68875.0
    335579316 1355239.0
    1230761 335601000.0
    201326717 67247793.0
    67228505 201381363.0
    119 3826851.0
    3790235 65666.0
    2494 6630221.0
    6556622 34374.0
    


```python
turnstiles_daily.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
      <th>PREV_DATE</th>
      <th>PREV_ENTRIES</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/02/2017</td>
      <td>5993559</td>
      <td>01/01/2017</td>
      <td>5992718.0</td>
      <td>841.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/03/2017</td>
      <td>5994505</td>
      <td>01/02/2017</td>
      <td>5993559.0</td>
      <td>946.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/04/2017</td>
      <td>5996263</td>
      <td>01/03/2017</td>
      <td>5994505.0</td>
      <td>1758.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/05/2017</td>
      <td>5997901</td>
      <td>01/04/2017</td>
      <td>5996263.0</td>
      <td>1638.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/06/2017</td>
      <td>5999649</td>
      <td>01/05/2017</td>
      <td>5997901.0</td>
      <td>1748.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
station_daily = turnstiles_daily.groupby(["STATION", "DATE"])[['DAILY_ENTRIES']].sum().reset_index()
station_daily.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STATION</th>
      <th>DATE</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1 AV</td>
      <td>01/02/2017</td>
      <td>10826.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1 AV</td>
      <td>01/03/2017</td>
      <td>12141.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1 AV</td>
      <td>01/04/2017</td>
      <td>21190.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1 AV</td>
      <td>01/05/2017</td>
      <td>22192.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1 AV</td>
      <td>01/06/2017</td>
      <td>22818.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
single_turnstile = turnstiles_daily[(turnstiles_daily["C/A"] == "A011") & 
(turnstiles_daily["UNIT"] == "R080") & 
(turnstiles_daily["SCP"] == "01-00-00") & 
(turnstiles_daily["STATION"] == "57 ST-7 AV")]

single_turnstile.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
      <th>PREV_DATE</th>
      <th>PREV_ENTRIES</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3808</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/02/2017</td>
      <td>887351426</td>
      <td>01/01/2017</td>
      <td>887352691.0</td>
      <td>1265.0</td>
    </tr>
    <tr>
      <th>3809</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/03/2017</td>
      <td>887349845</td>
      <td>01/02/2017</td>
      <td>887351426.0</td>
      <td>1581.0</td>
    </tr>
    <tr>
      <th>3810</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/04/2017</td>
      <td>887346840</td>
      <td>01/03/2017</td>
      <td>887349845.0</td>
      <td>3005.0</td>
    </tr>
    <tr>
      <th>3811</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/05/2017</td>
      <td>887343621</td>
      <td>01/04/2017</td>
      <td>887346840.0</td>
      <td>3219.0</td>
    </tr>
    <tr>
      <th>3812</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/06/2017</td>
      <td>887340347</td>
      <td>01/05/2017</td>
      <td>887343621.0</td>
      <td>3274.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
station_daily_57_av = station_daily[station_daily['STATION'] == '57 ST-7 AV']
station_daily_57_av.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STATION</th>
      <th>DATE</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>9292</th>
      <td>57 ST-7 AV</td>
      <td>01/02/2017</td>
      <td>16754.0</td>
    </tr>
    <tr>
      <th>9293</th>
      <td>57 ST-7 AV</td>
      <td>01/03/2017</td>
      <td>30382.0</td>
    </tr>
    <tr>
      <th>9294</th>
      <td>57 ST-7 AV</td>
      <td>01/04/2017</td>
      <td>32701.0</td>
    </tr>
    <tr>
      <th>9295</th>
      <td>57 ST-7 AV</td>
      <td>01/05/2017</td>
      <td>32620.0</td>
    </tr>
    <tr>
      <th>9296</th>
      <td>57 ST-7 AV</td>
      <td>01/06/2017</td>
      <td>32719.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
turnstiles_df.sort_values(["C/A", "UNIT", "SCP", "STATION", "DATE_TIME"], 
                          inplace=True, ascending=False)
turnstiles_df.drop_duplicates(subset=["C/A", "UNIT", "SCP", "STATION", "DATE_TIME"], inplace=True)

```


```python
turnstiles_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>LINENAME</th>
      <th>DIVISION</th>
      <th>DATE</th>
      <th>TIME</th>
      <th>ENTRIES</th>
      <th>DATE_TIME</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>198259</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>21:00:00</td>
      <td>5554</td>
      <td>2017-04-28 21:00:00</td>
    </tr>
    <tr>
      <th>198258</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>17:00:00</td>
      <td>5554</td>
      <td>2017-04-28 17:00:00</td>
    </tr>
    <tr>
      <th>198257</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>13:00:00</td>
      <td>5554</td>
      <td>2017-04-28 13:00:00</td>
    </tr>
    <tr>
      <th>198256</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>09:00:00</td>
      <td>5554</td>
      <td>2017-04-28 09:00:00</td>
    </tr>
    <tr>
      <th>198255</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>R</td>
      <td>RIT</td>
      <td>04/28/2017</td>
      <td>05:00:00</td>
      <td>5554</td>
      <td>2017-04-28 05:00:00</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>19:00:00</td>
      <td>5992418</td>
      <td>2016-12-31 19:00:00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>15:00:00</td>
      <td>5991971</td>
      <td>2016-12-31 15:00:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>11:00:00</td>
      <td>5991644</td>
      <td>2016-12-31 11:00:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>07:00:00</td>
      <td>5991565</td>
      <td>2016-12-31 07:00:00</td>
    </tr>
    <tr>
      <th>0</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>NQR456W</td>
      <td>BMT</td>
      <td>12/31/2016</td>
      <td>03:00:00</td>
      <td>5991546</td>
      <td>2016-12-31 03:00:00</td>
    </tr>
  </tbody>
</table>
<p>3143370 rows × 10 columns</p>
</div>




```python
#we are going to find the daily entries rather than cumulative 
```


```python
turnstiles_daily = (turnstiles_df
                        .groupby(["C/A", "UNIT", "SCP", "STATION", "DATE"],as_index=False)
                        .ENTRIES.first())
```


```python
turnstiles_daily
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/01/2017</td>
      <td>5992718</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/02/2017</td>
      <td>5993559</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/03/2017</td>
      <td>5994505</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/04/2017</td>
      <td>5996263</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/05/2017</td>
      <td>5997901</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>522003</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/25/2017</td>
      <td>5554</td>
    </tr>
    <tr>
      <th>522004</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/26/2017</td>
      <td>5554</td>
    </tr>
    <tr>
      <th>522005</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/27/2017</td>
      <td>5554</td>
    </tr>
    <tr>
      <th>522006</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>04/28/2017</td>
      <td>5554</td>
    </tr>
    <tr>
      <th>522007</th>
      <td>TRAM2</td>
      <td>R469</td>
      <td>00-05-01</td>
      <td>RIT-ROOSEVELT</td>
      <td>12/31/2016</td>
      <td>5554</td>
    </tr>
  </tbody>
</table>
<p>522008 rows × 6 columns</p>
</div>




```python
turnstiles_daily[['PRIVE_DATE','PRIVE_ENTRY']]=(turnstiles_daily
                                                .groupby(['C/A','UNIT','SCP','STATION'])['DATE','ENTRIES']
                                                .apply(lambda grp: grp.shift(1)))
```

    <ipython-input-19-f8d086f6a089>:1: FutureWarning: Indexing with multiple keys (implicitly converted to a tuple of keys) will be deprecated, use a list instead.
      turnstiles_daily[['PRIVE_DATE','PRIVE_ENTRY']]=(turnstiles_daily
    


```python
turnstiles_daily.columns
```




    Index(['C/A', 'UNIT', 'SCP', 'STATION', 'DATE', 'ENTRIES', 'PRIVE_DATE',
           'PRIVE_ENTRY'],
          dtype='object')




```python
turnstiles_daily[turnstiles_daily["ENTRIES"] < turnstiles_daily["PRIVE_ENTRY"]].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
      <th>PRIVE_DATE</th>
      <th>PRIVE_ENTRY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>111</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>12/31/2016</td>
      <td>5992638</td>
      <td>04/28/2017</td>
      <td>6157479.0</td>
    </tr>
    <tr>
      <th>223</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-01</td>
      <td>59 ST</td>
      <td>12/31/2016</td>
      <td>5475502</td>
      <td>04/28/2017</td>
      <td>5580208.0</td>
    </tr>
    <tr>
      <th>335</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-03-00</td>
      <td>59 ST</td>
      <td>12/31/2016</td>
      <td>842279</td>
      <td>04/28/2017</td>
      <td>904390.0</td>
    </tr>
    <tr>
      <th>446</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-03-01</td>
      <td>59 ST</td>
      <td>12/31/2016</td>
      <td>123216</td>
      <td>04/28/2017</td>
      <td>263779.0</td>
    </tr>
    <tr>
      <th>558</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-03-02</td>
      <td>59 ST</td>
      <td>12/31/2016</td>
      <td>5210246</td>
      <td>04/28/2017</td>
      <td>5350788.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
turnstiles_daily.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
      <th>PRIVE_DATE</th>
      <th>PRIVE_ENTRY</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/01/2017</td>
      <td>5993515</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/02/2017</td>
      <td>5994466</td>
      <td>01/01/2017</td>
      <td>5993515.0</td>
      <td>951.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/03/2017</td>
      <td>5996220</td>
      <td>01/02/2017</td>
      <td>5994466.0</td>
      <td>1754.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/04/2017</td>
      <td>5997865</td>
      <td>01/03/2017</td>
      <td>5996220.0</td>
      <td>1645.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A002</td>
      <td>R051</td>
      <td>02-00-00</td>
      <td>59 ST</td>
      <td>01/05/2017</td>
      <td>5999603</td>
      <td>01/04/2017</td>
      <td>5997865.0</td>
      <td>1738.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
station_daily = turnstiles_daily.groupby(["STATION", "DATE"])[['DAILY_ENTRIES']].sum().reset_index()
station_daily.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STATION</th>
      <th>DATE</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1 AV</td>
      <td>01/01/2017</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1 AV</td>
      <td>01/02/2017</td>
      <td>12265.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1 AV</td>
      <td>01/03/2017</td>
      <td>21132.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1 AV</td>
      <td>01/04/2017</td>
      <td>22147.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1 AV</td>
      <td>01/05/2017</td>
      <td>22632.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
station_totals = station_daily.groupby('STATION').sum()\
    .sort_values('DAILY_ENTRIES', ascending=False)\
    .reset_index()

station_totals.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STATION</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>34 ST-PENN STA</td>
      <td>34406526.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>GRD CNTRL-42 ST</td>
      <td>25470504.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>34 ST-HERALD SQ</td>
      <td>24798075.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>23 ST</td>
      <td>24751436.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>14 ST-UNION SQ</td>
      <td>22335841.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
single_turnstile = turnstiles_daily[(turnstiles_daily["C/A"] == "A011") & 
(turnstiles_daily["UNIT"] == "R080") & 
(turnstiles_daily["SCP"] == "01-00-00") & 
(turnstiles_daily["STATION"] == "57 ST-7 AV")]

single_turnstile.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C/A</th>
      <th>UNIT</th>
      <th>SCP</th>
      <th>STATION</th>
      <th>DATE</th>
      <th>ENTRIES</th>
      <th>PRIVE_DATE</th>
      <th>PRIVE_ENTRY</th>
      <th>DAILY_ENTRIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3807</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/01/2017</td>
      <td>887351557</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3808</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/02/2017</td>
      <td>887349985</td>
      <td>01/01/2017</td>
      <td>887351557.0</td>
      <td>1572.0</td>
    </tr>
    <tr>
      <th>3809</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/03/2017</td>
      <td>887347008</td>
      <td>01/02/2017</td>
      <td>887349985.0</td>
      <td>2977.0</td>
    </tr>
    <tr>
      <th>3810</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/04/2017</td>
      <td>887343813</td>
      <td>01/03/2017</td>
      <td>887347008.0</td>
      <td>3195.0</td>
    </tr>
    <tr>
      <th>3811</th>
      <td>A011</td>
      <td>R080</td>
      <td>01-00-00</td>
      <td>57 ST-7 AV</td>
      <td>01/05/2017</td>
      <td>887340563</td>
      <td>01/04/2017</td>
      <td>887343813.0</td>
      <td>3250.0</td>
    </tr>
  </tbody>
</table>
</div>




```python

station_daily_57_av['DAY_OF_WEEK_NUM'] = pd.to_datetime(station_daily_57_av['DATE']).dt.dayofweek
station_daily_57_av['WEEK_OF_YEAR'] = pd.to_datetime(station_daily_57_av['DATE']).dt.week
station_daily_57_av.head()
```

    <ipython-input-113-2a1e1cc4a8f2>:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      station_daily_57_av['DAY_OF_WEEK_NUM'] = pd.to_datetime(station_daily_57_av['DATE']).dt.dayofweek
    <ipython-input-113-2a1e1cc4a8f2>:2: FutureWarning: Series.dt.weekofyear and Series.dt.week have been deprecated.  Please use Series.dt.isocalendar().week instead.
      station_daily_57_av['WEEK_OF_YEAR'] = pd.to_datetime(station_daily_57_av['DATE']).dt.week
    <ipython-input-113-2a1e1cc4a8f2>:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      station_daily_57_av['WEEK_OF_YEAR'] = pd.to_datetime(station_daily_57_av['DATE']).dt.week
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STATION</th>
      <th>DATE</th>
      <th>DAILY_ENTRIES</th>
      <th>DAY_OF_WEEK_NUM</th>
      <th>WEEK_OF_YEAR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>9292</th>
      <td>57 ST-7 AV</td>
      <td>01/02/2017</td>
      <td>16754.0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9293</th>
      <td>57 ST-7 AV</td>
      <td>01/03/2017</td>
      <td>30382.0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9294</th>
      <td>57 ST-7 AV</td>
      <td>01/04/2017</td>
      <td>32701.0</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9295</th>
      <td>57 ST-7 AV</td>
      <td>01/05/2017</td>
      <td>32620.0</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9296</th>
      <td>57 ST-7 AV</td>
      <td>01/06/2017</td>
      <td>32719.0</td>
      <td>4</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.hist(station_totals['DAILY_ENTRIES'])
```




    (array([279.,  61.,  15.,   8.,   4.,   1.,   4.,   3.,   0.,   1.]),
     array([   49399. ,  3485111.7,  6920824.4, 10356537.1, 13792249.8,
            17227962.5, 20663675.2, 24099387.9, 27535100.6, 30970813.3,
            34406526. ]),
     <BarContainer object of 10 artists>)




    
![png](output_66_1.png)
    



```python
plt.figure(figsize=(40,10))
plt.plot(single_turnstile['DATE'], single_turnstile['DAILY_ENTRIES'])
plt.ylabel('# of Entries')
plt.xlabel('Date')
plt.xticks(rotation=45)
plt.title('Daily Entries for Turnstile A011/R080/01-00-00 at 57 ST-7 AV Station')
```




    Text(0.5, 1.0, 'Daily Entries for Turnstile A011/R080/01-00-00 at 57 ST-7 AV Station')




    
![png](output_67_1.png)
    

